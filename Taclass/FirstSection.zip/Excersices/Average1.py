i=0
sum=0
while True:
    n = int(input('Enter Number : '))
    if n<0:
        break
    else:
        sum+=n
        i+=1
print("Average Is : ",sum/i)
input()
