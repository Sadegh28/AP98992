import turtle
sc=turtle.Screen()
tt=turtle.Turtle()

for i in range(20):
    tt.forward(i * 10)
    tt.right(144)
sc.mainloop()