n=int(input("Please Enter First Number  : "))
m=int(input("Please Enter Secound Number : "))

for i in range(n,m+1):
    if i==0 or i==1:
        continue
    flag=True
    for j in range(2,int(i/2+1)):
        if i%j==0:
            flag=False
            break
    if flag==True:
        print(i,end=' ')
input()
