import turtle
sc=turtle.Screen()
tt=turtle.Turtle()
colorr=['red','blue','black','yellow','orange','green']
def part( total, length, breadth, col ):
    angleInc = (total-2)*180/total
    tt.width( breadth )
    tt.color( col )
    for i in range(total):
        tt.forward( length )
        tt.left( 180-angleInc )
def rosette( total, length, width, color, angleInc ):
    # added forced type int for python3
    for i in range( int(360/angleInc) ):
        part( total, length, width, color )
        tt.left( angleInc )
tt.speed(0) # draw as fast as possible
# call the functions
sc.title("Rosette")
rosette(10,40,1,"blue",36)
rosette(5,80,1,"red",36)
sc.mainloop()