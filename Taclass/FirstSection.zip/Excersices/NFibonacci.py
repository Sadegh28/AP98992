x=int(input("Please Enter A Number : "))
a=1
b=1
print(a,b,end=' ')
for i in range(2,x):
    c=a+b
    a=b
    b=c
    print(c,end=' ')
input()