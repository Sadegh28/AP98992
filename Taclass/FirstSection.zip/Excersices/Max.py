n = int(input('Enter Number : '))
max=n
while True:
    n = int(input('Enter Number : '))
    flag=True
    if n == 0 or n == 1:
        flag = False
    for i in range(2,n//2):
        if n%i==0:
            flag=False
            break
    if flag==True:
        break
    else:
        if n>max:
            max=n
print("max is :",max)
input()
