import turtle
tt=turtle.Turtle()
sc=turtle.Screen()
n = int(input("Input N : "))
if n>=3:
    degree = (180*(n-2))/n
    tt.pensize(2)
    for i in range(n):
        tt.forward(100)
        tt.left(180-degree)
    sc.mainloop()
else:
    print("Your Number (N) is Incorrect.")