import turtle
tt=turtle.Turtle()
sc=turtle.Screen()
colors=['blue','green','purple','yellow','orange','red']
tt.speed(100)
for x in range(300):
    tt.color(colors[x%6])
    tt.pensize(x/100 +1)
    tt.forward(x)
    tt.left(59)
sc.mainloop()