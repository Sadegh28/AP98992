x=int(input("Please Enter A Number : "))
flag = True
for i in range(2,x):
    if x%i==0:
        flag=False
        break
if flag==True:
    print("Your Number Is Prime")
else:
    print("Your Number is'nt prime")

input()