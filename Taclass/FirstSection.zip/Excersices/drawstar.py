import turtle
sc=turtle.Screen()
tt=turtle.Turtle()
tt.color('blue')
tt.begin_fill()
for i in range(5):
    tt.forward(200)
    tt.right(144)
tt.end_fill()

sc.mainloop()